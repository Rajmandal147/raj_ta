package com.task.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class User {

	@Id
	@GeneratedValue
	@Column
	private int userId;
	@Column
	private String userName;
	@Column
	private String userPass;
	@Column
	private String address;
	@Column
	private String city;
	@Column
	private String state;
	@Column
	private String dob;
	@Column
	private String gender;
	
	
	public User(int userId, String userName, String userPass, String address, String city, String state, String dob,
			String gender) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPass = userPass;
		this.address = address;
		this.city = city;
		this.state = state;
		this.dob = dob;
		this.gender = gender;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserPass() {
		return userPass;
	}


	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public User() {
		super();
		
	}
	
}
