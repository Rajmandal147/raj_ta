package com.task.dao;
import com.task.dto.*;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class UserDaoImple implements UserDao {
	@Autowired
	private HibernateTemplate hibernateTemple;

    public void insertUser(User user) {
    	
    	hibernateTemple.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
			  Transaction tr= session.beginTransaction();
			  session.save(user);
			  tr.commit();
			  session.flush();
			  session.close();
				return null;
			}
		});
    	
    }
	@Override
	public boolean checkUser(User user) {
		
	boolean b=hibernateTemple.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				Query q=session.createQuery("from User where userName=? and userPass=?");
				q.setString(0, user.getUserName());
				q.setString(1, user.getUserPass());
				List<User> li=q.list();
				boolean flag= !li.isEmpty();
				user.setUserId(li.get(0).getUserId());
				tr.commit();
				session.flush();
				session.close();
				return  flag;
			}
		});
		
		return b;
	}

	@Override
	public List<User> selectAll(int userId) {
		List<User> userList=hibernateTemple.execute(new HibernateCallback<List<User>>() {

			@Override
			public List<User> doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				Query al=session.createQuery("from User");
				List<User> all=al.list();
				Query re=session.createQuery("from User where userId=?");
				re.setInteger(0, userId);
				all.remove(re);
				return all;
			}
		});
		return userList;
	}

}
