package com.task.dao;

import java.util.List;

import com.task.dto.User;

public interface UserDao {

	void insertUser(User user);

	boolean checkUser(User user);

	List<User> selectAll(int userId);

}
