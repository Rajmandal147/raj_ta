package com.task.service;

import java.util.List;

import com.task.dto.User;

public interface UserService {
	void addUser(User user);
	boolean findUser(User user);
	List<User> listAll(int userId);

}