package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;


import com.cdac.dto.User;

@Repository
public class UserDaoImple implements UserDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void insertUser(User user) {  //6) now user object came here and hibernate save it to database and control go back
		                                 //   to UserServiceImple.java and then UserController
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(user);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	
	//=====================================valid or not===================================
	@Override
	public boolean checkUser(User user) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from User where userName = ? and userPass = ?");
				q.setString(0, user.getUserName());
				q.setString(1, user.getUserPass());
				
				
				List<User> li = q.list();
				boolean flag = !li.isEmpty(); // li is not Empty====>flag=true
				user.setUserId(li.get(0).getUserId()); 
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
			
		});
		return b; //if user present true
	}
 
	//====================================
	
	@Override
	public User selectUser(int UserId) {
		User user = hibernateTemplate.execute(new HibernateCallback<User>() {

			@Override
			public User doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				User ex = (User)session.get(User.class, UserId);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return user;
	}

	
	
	
//=====================================
	
	
	@Override
	public List<User> selectAll(int Id) {
		List<User> userList = hibernateTemplate.execute(new HibernateCallback<List<User>>() {

			@Override
			public List<User> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Expense where userId = ?");
				q.setInteger(0, userId);
				List<User> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return userList;
	}

	
}
