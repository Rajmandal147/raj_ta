package com.cdac.dao;

import java.util.List;


import com.cdac.dto.User;

public interface UserDao {
	void insertUser(User user);
	boolean checkUser(User user);
	User selectUser(int userId);
	List<User> selectAll(int Id);
}
