package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.cdac.dto.User;
import com.cdac.service.UserService;
import com.cdac.valid.UserValidator;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private UserValidator userValidator;
	                          //Request come from index.jsp
	@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("user", new User());
		return "reg_form";  //1)creating an Object and sending to (reg_form) page.
	}
	
	@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
	public String register(User user,ModelMap map) {
		userService.addUser(user); //3) now User object have  an data and we are calling (userService.addUser(user)) so 
		                           //control goes to (userServiceImple.java)
		
		return "index";            //7)now control is here and open index.jsp
	}
	
	
	//===================================LogIN=====================================
	
	                         //8) control came here after sign in
	@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("user", new User());// 9) user object created and store in the model map
		return "login_form";// 10) go to (login_form.jsp)
	}
	
	
	                  // 12) control come here
	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(User user,ModelMap map) { //13) user Object is sent and modelMapis created
		
		
		boolean b = userService.findUser(user);// 14) checking is user is present or not
		if(b) {
			
			return "home";//if yes go to home.jsp
		}else {
			map.put("user", new User());
			return "login_form"; //if no then login again
		}
	}
	
	@RequestMapping(value = "/User_list.htm",method = RequestMethod.GET)
	public String allUser(ModelMap map,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		List<User> li = userService.selectAll(userId);
		map.put("userList", li);
		return "user_list";
	}
	
	
}




//================================================================================

////8) control came here after sign in
//@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
//public String prepLogForm(ModelMap map) {
//map.put("user", new User());// 9) user object created and store in the model map
//return "login_form";// 10) go to (login_form.jsp)
//}
//
//
//           // 12) control come here
//@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
//public String login(User user,BindingResult result,ModelMap map,HttpSession session) {
//
//userValidator.validate(user, result);
//if(result.hasErrors()) {
//	return "login_form";
//}
//
//boolean b = userService.findUser(user);
//if(b) {
//	session.setAttribute("user", user); 
//	return "home";
//}else {
//	map.put("user", new User());
//	return "login_form";
//}
//}
//
//@RequestMapping(value = "/User_list.htm",method = RequestMethod.GET)
//public String allUser(ModelMap map,HttpSession session) {
//int userId = ((User)session.getAttribute("user")).getUserId();
//List<User> li = userService.selectAll(userId);
//map.put("userList", li);
//return "user_list";
//}
//
//
//}

