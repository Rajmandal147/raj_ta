package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.UserDao;

import com.cdac.dto.User;

@Service
public class UserServiceImple implements UserService {
	
	@Autowired
	private UserDao userDao;

	@Override
	public void addUser(User user) {  //4) this method is call now
		userDao.insertUser(user);     //5)control is here and call (userDao.insertUser(user)) method  of (UserDaoImple.java)
	}

	@Override
	public boolean findUser(User user) {
		return userDao.checkUser(user);
	}
	
	@Override
	public List<User> selectAll(int userId) {
		return UserDao.selectAll(userId);
	}
	
}
