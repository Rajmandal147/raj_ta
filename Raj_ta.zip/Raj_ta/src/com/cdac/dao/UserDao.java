package com.cdac.dao;

import java.util.List;


import com.cdac.dto.User;

public interface UserDao {
	void insertUser(User user);
	boolean checkUser(User user);
	public static List<User> selectAll(int userId) {
		// TODO Auto-generated method stub
		return null;
	}
}
